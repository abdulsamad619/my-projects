package main;

public class SortedLinkedList<T extends Comparable> {

    private final class Node<T extends Comparable> {

        T data;
        Node next;

        Node(T val, Node n) {
            data = val;
            next = n;
        }

        Node(T val) {
            this(val, null);
        }
    }
    private Node first;

    public SortedLinkedList() {
        first = null;
    }

    public boolean isEmpty() {
        return first == null;
    }

    public int size() {
        int count = 0;
        Node p = first;
        while (p != null) {
            count++;
            p = p.next;
        }
        return count;
    }

    public void add(T element) {
        Node<T> new_node = new Node(element);
        Node<T> current;

        if (first == null) {
            first = new_node;
            new_node.next = null;
        } else if ((first.data.compareTo(new_node.data)) >= 0) {
            new_node.next = first;
            first = new_node;
        } else {

            current = first;

            while (current.next != null && (current.next.data.compareTo(new_node.data)) < 0) {
                current = current.next;
            }
            new_node.next = current.next;
            current.next = new_node;
        }
    }

    @Override
    public String toString() {
        String listOfItems = "";
        Node cur;
        cur = first;
        while (cur.next != null) {
            listOfItems = listOfItems.concat(cur.data + "->");
            cur = cur.next;
        }
        listOfItems += "end";
        return listOfItems;
    }
public boolean remove(T element) {
        Node<T> cur;
        Node<T> temp;
        if (first == null) {
            System.out.println("List is Empty");
            return false;
        } else if ((first.data.compareTo(element)) == 0) {
            first = first.next;
            return true;
        }

        cur = first;
        while (cur.next != null) {
            if ((cur.next.data.compareTo(element)) == 0) {
                cur.next = cur.next.next;

            }
            cur = cur.next;
        }

        return false;

    }
}
