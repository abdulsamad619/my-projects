// 1.Yes,i  noticed SortedLinkedList<T> performances is faster then ArrayList<T> classes   when adding items.
// 2.Same as while deleting items SortedLinkedList<T> performances is faster then ArrayList<T> classes
// 3.I will choose SortedLinkekdList<T> over ArrayList<T> when data is big and we cant call additional sorting algoritham.
package main;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.Collections;

public class Main {

    public static void main(String[] args) {
        SortedLinkedList<String> list = new SortedLinkedList<>();
        SortedLinkedList<Integer> list2 = new SortedLinkedList<>();
          
        ArrayList<String> araylist = new ArrayList<String>();
        System.out.println("Deleting IN SortedLinkedList...");
        try {
            File myObj = new File("C:\\Users\\H.A.R\\Desktop\\CPP,C,JAVA,PYTHON,JAVASCRIPT\\read.txt");
            Scanner myReader = new Scanner(myObj);
            while (myReader.hasNextLine()) {
                String data = myReader.nextLine();
//                            ADDING INTO LIST
                list.add(data);
//                            ADDING INTO ARRAYLIST
//                araylist.add(data);
//        SORTING THE ARRAYLIST 
//                Collections.sort(araylist);
      
            }
            myReader.close();
        } catch (FileNotFoundException e) {
            System.out.println("An error occurred. " + e.getMessage());
        }
        list.remove("Davi");
        
//       System.out.println( list.toString());
       
    }
}
